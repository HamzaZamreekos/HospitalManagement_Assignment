﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Infrastructure.Oracle
{
    public static class Static
    {
        public static string ConnectionString = "Data Source=localhost:1521/FREE;User Id=C##john;Password=password;";
    }
}
