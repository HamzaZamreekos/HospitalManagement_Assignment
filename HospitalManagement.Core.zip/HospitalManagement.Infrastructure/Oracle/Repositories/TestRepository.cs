﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Infrastructure.Oracle.Repositories
{
	public class TestRepository
	{

	}
}
