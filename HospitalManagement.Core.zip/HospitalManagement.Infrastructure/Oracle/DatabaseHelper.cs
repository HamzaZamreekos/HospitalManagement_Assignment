﻿using HospitalManagement.Core.Attributes;
using HospitalManagement.Core.Entities;
using HospitalManagement.Core.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace HospitalManagement.Infrastructure.Oracle
{
	public static class DatabaseHelper
	{
		public static OracleConnection dbConnection= new OracleConnection(Static.ConnectionString);
		static DatabaseHelper()
		{
			dbConnection.Open();
		}

		public static DatabaseResponse ExecuteCommand(OracleCommand oracleCommand)
		{
			var response = new DatabaseResponse();
			try
			{
				response.Success = oracleCommand.ExecuteNonQuery() > 0;
			}
			catch (Exception ex)
			{
				response.Success = false;
			}
			return response;

		}
		public static List<TEntity> GenericSelectCommand<TEntity>() where TEntity : class
		{
			List<TEntity> entities = new List<TEntity>();
			var command = dbConnection.CreateCommand();

			Type entityType = typeof(TEntity);

			command.CommandText = $"SELECT * FROM {entityType.Name}s";
			using (OracleDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					object EntityInstance = Activator.CreateInstance(entityType);
					PropertyInfo[] arrayPropertyInfos = entityType.GetProperties();
					for (int i = 0; i < arrayPropertyInfos.Length; i++)
					{
						PropertyInfo property = arrayPropertyInfos[i];
						if (property.PropertyType.IsClass == true
							&& property.PropertyType != typeof(string)
							&& property.PropertyType != typeof(DateTime)
							&& property.PropertyType != typeof(decimal)
							&& property.PropertyType != typeof(double)
							) continue;
						var readerValue = reader[property.Name];
						property.SetValue(EntityInstance, Convert.ChangeType(readerValue, property.PropertyType));
						entities.Add(EntityInstance as TEntity);
					}
				}

			}
			return entities;
		}

		public static OracleCommand GenericInsertGenerator(object targetObject)
		{
			var command = dbConnection.CreateCommand();

			StringBuilder commandTextBuilder_names = new StringBuilder();
			StringBuilder commandTextBuilder_values = new StringBuilder();

			Type tModelType = targetObject.GetType();
			PropertyInfo[] arrayPropertyInfos = tModelType.GetProperties();

			for (int i = 0; i < arrayPropertyInfos.Length; i++)
			{
				PropertyInfo property = arrayPropertyInfos[i];

				if (property.PropertyType.IsClass == true
					&& property.PropertyType != typeof(string)
					&& property.PropertyType != typeof(DateTime)
					&& property.PropertyType != typeof(decimal)
					&& property.PropertyType != typeof(double)
					) continue;

				if (property.CustomAttributes.Any(x => x.AttributeType == typeof(PrimaryKeyAttribute) 
													|| x.AttributeType == typeof(ForeignKeyAttribute)))
					continue;

				commandTextBuilder_names.Append($"{property.Name}");
				commandTextBuilder_values.Append($":{property.Name}");
				if (i != arrayPropertyInfos.Length - 1)
				{
					commandTextBuilder_names.Append(", ");
					commandTextBuilder_values.Append(", ");
				}

				command.Parameters.Add(new OracleParameter(property.Name, property.GetValue(targetObject)));
			}

			command.CommandText = $"INSERT INTO {tModelType.Name}s ({commandTextBuilder_names.ToString()}) VALUES ({commandTextBuilder_values.ToString()})";
			return command;
		}
	}
}
