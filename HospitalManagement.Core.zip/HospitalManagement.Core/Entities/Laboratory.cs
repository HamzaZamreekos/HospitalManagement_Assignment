﻿
namespace HospitalManagement.Core.Entities
{
    public class Laboratory
    {
        public string Name { get; set; }
        public int NumberOfRooms { get; set; }
        public int WardId { get; set; }
        public int HospitalId { get; set; }

        public Ward Ward {  get; set; }
        public Hospital Hospital { get; set; }
    }
}
