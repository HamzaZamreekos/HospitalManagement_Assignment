﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Core.Entities
{
	public class LaboratoryRoom
	{
		public int NumberOfDevices { get; set; }
	}
}
