﻿using HospitalManagement.Core.Entities;
using HospitalManagement.Core.Enums;
using HospitalManagement.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Core.Repositories.Interfaces
{
    public interface IPatientRepository
    {
		(DatabaseResponse addReceiptResponse, DatabaseResponse updatePatientResponse) DischargePatient(Patient patient,
                                                                                                            double paymentAmount,
                                                                                                            StateAtDischarge stateAtDischarge
                                                                                                        );

        DatabaseResponse<List<Patient>> GetAllPatientsWithReceipts();
        DatabaseResponse AddPatient(Patient patient);
        DatabaseResponse RemovePatient(int patientId);
        DatabaseResponse<List<Patient>> GetAllPatients();
        DatabaseResponse<Patient> GetPatient(int patientId);
    }
}
