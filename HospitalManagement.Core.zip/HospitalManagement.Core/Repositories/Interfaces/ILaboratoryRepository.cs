﻿using HospitalManagement.Core.Entities;
using HospitalManagement.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Core.Repositories.Interfaces
{
	public interface ILaboratoryRepository
	{
		DatabaseResponse AddLaboratory(Laboratory laboratory);
		DatabaseResponse<List<Laboratory>> GetAllLaboratories();
		DatabaseResponse<Laboratory> GetLaboratory(int laboratoryId);
	}
}
