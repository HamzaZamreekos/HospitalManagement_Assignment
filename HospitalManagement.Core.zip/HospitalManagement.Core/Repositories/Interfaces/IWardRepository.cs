﻿using HospitalManagement.Core.Entities;
using HospitalManagement.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Core.Repositories.Interfaces
{
    public interface IWardRepository
    {
        DatabaseResponse AddWard(Ward ward);
        DatabaseResponse<List<Ward>> GetAllWards();
        DatabaseResponse<Ward> GetWard(int wardId);
    }
}
