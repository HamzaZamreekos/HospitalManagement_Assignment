﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagement.Core.Enums
{
    public enum StateAtDischarge
    {
        Alive,
        Dead, 
        Readmission
    }
}
